package com.bonestudio.animation.ui.editor

import android.graphics.Bitmap
import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import com.bonestudio.animation.cutout.CutoutSession
import com.bonestudio.animation.cutout.Selection
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

private fun checkerBrush(): Brush {
    val bmp = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val a = android.graphics.Paint()
    a.color = 0xFF3A3D4A.toInt()
    val b = android.graphics.Paint()
    b.color = 0xFF4A4E5E.toInt()
    c.drawRect(0f, 0f, 32f, 32f, a)
    c.drawRect(0f, 0f, 16f, 16f, b)
    c.drawRect(16f, 16f, 32f, 32f, b)
    return ShaderBrush(ImageShader(bmp.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
}

private fun polyPath(points: List<PointF>, close: Boolean): Path {
    val p = Path()
    if (points.isEmpty()) return p
    p.moveTo(points[0].x, points[0].y)
    for (i in 1 until points.size) p.lineTo(points[i].x, points[i].y)
    if (close) p.close()
    return p
}

@Composable
fun CutoutCanvas(controller: EditorController, session: CutoutSession, modifier: Modifier = Modifier) {
    val tool = controller.tool
    var zoom by remember { mutableFloatStateOf(1f) }
    var fitZoom by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val dragPoints = remember { mutableStateListOf<PointF>() }
    var cursor by remember { mutableStateOf<PointF?>(null) }
    val checker = remember { checkerBrush() }

    val imgW = session.working.width
    val imgH = session.working.height

    LaunchedEffect(size, imgW, imgH) {
        if (size.width > 0 && size.height > 0) {
            val f = min(size.width.toFloat() / imgW, size.height.toFloat() / imgH) * 0.96f
            fitZoom = f
            zoom = f
            offset = Offset((size.width - imgW * f) / 2f, (size.height - imgH * f) / 2f)
        }
    }
    LaunchedEffect(tool) {
        dragPoints.clear()
        cursor = null
    }

    val sel = session.selection
    val selPath = remember(sel) { if (sel != null) polyPath(sel.points, true) else null }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .clipToBounds()
            .background(Color(0xFF0D0E13))
            .onSizeChanged { size = it }
            .pointerInput(tool, session) {
                val slop = viewConfiguration.touchSlop
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startPos = down.position
                    var multi = false
                    var moved = false
                    var erasing = false

                    fun toImg(p: Offset): PointF = PointF((p.x - offset.x) / zoom, (p.y - offset.y) / zoom)

                    var curImg = toImg(startPos)
                    var lastImg = curImg
                    if (tool == Tool.ERASER) cursor = curImg

                    do {
                        val event = awaitPointerEvent()
                        val active = event.changes.count { it.pressed }
                        if (active >= 2) {
                            multi = true
                            dragPoints.clear()
                            cursor = null
                            val z = event.calculateZoom()
                            val pan = event.calculatePan()
                            val c = event.calculateCentroid()
                            if (c.isSpecified) {
                                val newZoom = (zoom * z).coerceIn(fitZoom * 0.4f, fitZoom * 24f)
                                offset = c - (c - offset) * (newZoom / zoom) + pan
                                zoom = newZoom
                            }
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        } else if (!multi) {
                            val ch = event.changes.firstOrNull { it.pressed }
                            if (ch != null) {
                                val pos = ch.position
                                if (!moved && (pos - startPos).getDistance() > slop) moved = true
                                curImg = toImg(pos)
                                when (tool) {
                                    Tool.PAN -> {
                                        val d = ch.positionChange()
                                        offset += d
                                        if (d != Offset.Zero) ch.consume()
                                    }
                                    Tool.RECT -> {
                                        if (moved) {
                                            if (dragPoints.size < 2) {
                                                dragPoints.clear()
                                                dragPoints.add(toImg(startPos))
                                                dragPoints.add(curImg)
                                            } else {
                                                dragPoints[1] = curImg
                                            }
                                            ch.consume()
                                        }
                                    }
                                    Tool.FREEHAND -> {
                                        if (moved) {
                                            if (dragPoints.isEmpty()) dragPoints.add(toImg(startPos))
                                            val l = dragPoints.last()
                                            if (hypot(curImg.x - l.x, curImg.y - l.y) * zoom > 2f) {
                                                dragPoints.add(curImg)
                                            }
                                            ch.consume()
                                        }
                                    }
                                    Tool.POLYGON -> {
                                        // taps are handled when the finger is lifted
                                    }
                                    Tool.ERASER -> {
                                        cursor = curImg
                                        if (moved) {
                                            if (!erasing) {
                                                erasing = session.beginErase()
                                                lastImg = toImg(startPos)
                                            }
                                            if (erasing) {
                                                session.erase(lastImg, curImg, controller.eraserRadius)
                                                lastImg = curImg
                                            }
                                            ch.consume()
                                        }
                                    }
                                }
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    if (!multi) {
                        when (tool) {
                            Tool.PAN -> {}
                            Tool.RECT -> {
                                if (dragPoints.size >= 2) {
                                    val a = dragPoints.first()
                                    val b = dragPoints.last()
                                    if (abs(a.x - b.x) * zoom > 8f && abs(a.y - b.y) * zoom > 8f) {
                                        session.setSelection(Selection.rect(a, b))
                                    }
                                }
                            }
                            Tool.FREEHAND -> {
                                if (dragPoints.size >= 3) {
                                    session.setSelection(Selection(dragPoints.toList()))
                                }
                            }
                            Tool.POLYGON -> {
                                if (!moved) {
                                    val poly = session.polygon
                                    var closed = false
                                    if (poly.size >= 3) {
                                        val f = poly[0]
                                        val sx = f.x * zoom + offset.x
                                        val sy = f.y * zoom + offset.y
                                        if (hypot(startPos.x - sx, startPos.y - sy) < 44f) {
                                            session.closePolygon()
                                            closed = true
                                        }
                                    }
                                    if (!closed) session.addPolygonPoint(toImg(startPos))
                                }
                            }
                            Tool.ERASER -> {
                                if (!moved && !erasing) {
                                    if (session.beginErase()) {
                                        val p = toImg(startPos)
                                        session.erase(p, p, controller.eraserRadius)
                                    }
                                }
                                cursor = null
                            }
                        }
                    }
                    dragPoints.clear()
                    cursor = null
                }
            }
    ) {
        @Suppress("UNUSED_VARIABLE")
        val redrawTrigger = session.version
        val bmp = session.working
        val stroke = 2f / zoom

        withTransform({
            translate(offset.x, offset.y)
            scale(zoom, zoom, Offset.Zero)
        }) {
            drawRect(
                brush = checker,
                topLeft = Offset.Zero,
                size = Size(bmp.width.toFloat(), bmp.height.toFloat())
            )
            drawImage(bmp.asImageBitmap())

            selPath?.let {
                drawPath(it, Color(0x332F80FF))
                drawPath(it, Color.White, style = Stroke(width = stroke))
                drawPath(
                    it,
                    Color(0xFF2F80FF),
                    style = Stroke(
                        width = stroke,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f / zoom, 10f / zoom))
                    )
                )
            }

            val poly = session.polygon
            if (poly.isNotEmpty()) {
                val pts = poly.toList()
                drawPath(polyPath(pts, false), Color(0xFFFFD54F), style = Stroke(width = stroke))
                pts.forEachIndexed { i, pt ->
                    drawCircle(
                        color = if (i == 0) Color(0xFF69F0AE) else Color(0xFFFFD54F),
                        radius = (if (i == 0) 9f else 5f) / zoom,
                        center = Offset(pt.x, pt.y)
                    )
                }
            }

            if (dragPoints.size >= 2) {
                if (tool == Tool.RECT) {
                    val a = dragPoints.first()
                    val b = dragPoints.last()
                    drawRect(
                        color = Color(0xFFFFD54F),
                        topLeft = Offset(min(a.x, b.x), min(a.y, b.y)),
                        size = Size(abs(a.x - b.x), abs(a.y - b.y)),
                        style = Stroke(width = stroke)
                    )
                } else if (tool == Tool.FREEHAND) {
                    drawPath(polyPath(dragPoints.toList(), false), Color(0xFFFFD54F), style = Stroke(width = stroke))
                }
            }

            cursor?.let {
                drawCircle(
                    color = Color.White,
                    radius = controller.eraserRadius,
                    center = Offset(it.x, it.y),
                    style = Stroke(width = stroke)
                )
            }
        }
    }
}
