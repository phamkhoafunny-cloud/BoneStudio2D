package com.bonestudio.animation.imageprocessing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlin.math.max
import kotlin.math.roundToInt

object BitmapDecoder {
    /** Largest canvas side. Keeps RAM sane (undo history stores several copies). */
    const val MAX_SIDE = 1600

    fun decodeScaled(context: Context, uri: Uri, maxSide: Int = MAX_SIDE): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inMutable = true
        }
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null

        val longest = max(decoded.width, decoded.height)
        var result: Bitmap = decoded
        if (longest > maxSide) {
            val s = maxSide.toFloat() / longest
            val nw = (decoded.width * s).roundToInt().coerceAtLeast(1)
            val nh = (decoded.height * s).roundToInt().coerceAtLeast(1)
            result = Bitmap.createScaledBitmap(decoded, nw, nh, true)
            if (result !== decoded) decoded.recycle()
        }
        if (!result.isMutable || result.config != Bitmap.Config.ARGB_8888) {
            val copy = result.copy(Bitmap.Config.ARGB_8888, true) ?: return null
            if (copy !== result) result.recycle()
            result = copy
        }
        return result
    }
}
