package com.bonestudio.animation.cutout

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect

object CutoutEngine {

    class CutResult(val bitmap: Bitmap, val bounds: Rect)

    /**
     * Returns a bitmap with exactly the same size as [src] (so the part keeps its original position),
     * where every pixel outside [selection] has alpha 0. Returns null when nothing visible is selected.
     */
    fun cut(src: Bitmap, selection: Selection): CutResult? {
        val w = src.width
        val h = src.height

        val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        Canvas(mask).drawPath(selection.toPath(), maskPaint)

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawBitmap(src, 0f, 0f, null)
        val keep = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        canvas.drawBitmap(mask, 0f, 0f, keep)
        mask.recycle()

        val bounds = opaqueBounds(out)
        if (bounds == null) {
            out.recycle()
            return null
        }
        return CutResult(out, bounds)
    }

    fun opaqueBounds(bmp: Bitmap): Rect? {
        val w = bmp.width
        val h = bmp.height
        val row = IntArray(w)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) {
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                if ((row[x] ushr 24) != 0) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    maxY = y
                }
            }
        }
        if (maxX < 0) return null
        return Rect(minX, minY, maxX + 1, maxY + 1)
    }
}
