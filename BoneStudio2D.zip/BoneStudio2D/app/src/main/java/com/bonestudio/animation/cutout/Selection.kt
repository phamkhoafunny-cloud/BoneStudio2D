package com.bonestudio.animation.cutout

import android.graphics.Path
import android.graphics.PointF
import kotlin.math.max
import kotlin.math.min

/** A closed polygon selection in image (canvas) coordinates. Rectangle/Freehand/Polygon all produce this. */
class Selection(val points: List<PointF>) {

    fun toPath(): Path {
        val path = Path()
        if (points.isEmpty()) return path
        path.moveTo(points[0].x, points[0].y)
        for (i in 1 until points.size) {
            path.lineTo(points[i].x, points[i].y)
        }
        path.close()
        return path
    }

    companion object {
        fun rect(a: PointF, b: PointF): Selection {
            val l = min(a.x, b.x)
            val t = min(a.y, b.y)
            val r = max(a.x, b.x)
            val bt = max(a.y, b.y)
            return Selection(listOf(PointF(l, t), PointF(r, t), PointF(r, bt), PointF(l, bt)))
        }
    }
}
