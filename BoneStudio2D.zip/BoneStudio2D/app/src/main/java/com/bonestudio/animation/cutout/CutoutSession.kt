package com.bonestudio.animation.cutout

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Editing state of the cutout editor: the working bitmap, the current selection and undo/redo history.
 * Bitmaps are copy-on-write: a snapshot never changes after it was stored.
 */
class CutoutSession(initial: Bitmap) {

    private class Snapshot(val bitmap: Bitmap, val selection: Selection?)

    var working by mutableStateOf(initial)
        private set

    var selection by mutableStateOf<Selection?>(null)
        private set

    /** Polygon vertices placed so far (not yet closed). */
    val polygon = mutableStateListOf<PointF>()

    /** Incremented whenever the pixels of [working] change, so the canvas redraws. */
    var version by mutableIntStateOf(0)
        private set

    var canUndo by mutableStateOf(false)
        private set

    var canRedo by mutableStateOf(false)
        private set

    /** True when [working] changed since the last save to disk. */
    @Volatile
    var dirty: Boolean = false

    private val undoStack = ArrayDeque<Snapshot>()
    private val redoStack = ArrayDeque<Snapshot>()

    private val clearStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val clearFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        style = Paint.Style.FILL
    }

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun pushUndo() {
        undoStack.addLast(Snapshot(working, selection))
        while (undoStack.size > MAX_HISTORY) undoStack.removeFirst()
        redoStack.clear()
        refreshFlags()
    }

    fun setSelection(sel: Selection?) {
        if (sel == null && selection == null) return
        pushUndo()
        selection = sel
        polygon.clear()
    }

    fun clearSelection() {
        if (selection != null) {
            setSelection(null)
        } else {
            polygon.clear()
        }
    }

    fun addPolygonPoint(p: PointF) {
        polygon.add(p)
    }

    fun closePolygon() {
        if (polygon.size >= 3) {
            setSelection(Selection(polygon.toList()))
        }
        polygon.clear()
    }

    /** Starts an eraser stroke: stores history and makes a private copy of the bitmap to draw on. */
    fun beginErase(): Boolean {
        val copy = working.copy(Bitmap.Config.ARGB_8888, true) ?: return false
        pushUndo()
        working = copy
        dirty = true
        version++
        return true
    }

    fun erase(from: PointF, to: PointF, radius: Float) {
        val canvas = Canvas(working)
        clearStroke.strokeWidth = radius * 2f
        canvas.drawLine(from.x, from.y, to.x, to.y, clearStroke)
        canvas.drawCircle(to.x, to.y, radius, clearFill)
        version++
    }

    fun undo() {
        if (polygon.isNotEmpty()) {
            polygon.removeAt(polygon.lastIndex)
            return
        }
        val s = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(Snapshot(working, selection))
        restore(s)
    }

    fun redo() {
        val s = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(Snapshot(working, selection))
        restore(s)
    }

    private fun restore(s: Snapshot) {
        if (s.bitmap !== working) dirty = true
        working = s.bitmap
        selection = s.selection
        polygon.clear()
        version++
        refreshFlags()
    }

    companion object {
        private const val MAX_HISTORY = 12
    }
}
