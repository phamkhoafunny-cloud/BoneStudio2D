@file:OptIn(ExperimentalMaterial3Api::class)

package com.bonestudio.animation.ui.editor

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.bonestudio.animation.R
import com.bonestudio.animation.core.PartInfo
import com.bonestudio.animation.cutout.CutoutSession
import com.bonestudio.animation.ui.components.NameDialog

private val PartSuggestions = listOf("Head", "Body", "Left Arm", "Right Arm", "Left Leg", "Right Leg", "Hair", "Weapon")

@Composable
fun EditorScreen(controller: EditorController, onBack: () -> Unit) {
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val lifecycleOwner = LocalLifecycleOwner.current
    var showCut by remember { mutableStateOf(false) }
    var showParts by remember { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) controller.requestSave()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    BackHandler(onBack = onBack)

    LaunchedEffect(controller.message) {
        val m = controller.message
        if (m != null) {
            snackbar.showSnackbar(context.getString(m.res, *m.args.toTypedArray()))
            controller.message = null
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) controller.importImage(uri)
    }

    val session = controller.session
    val meta = controller.meta

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(meta?.name ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    if (session != null) {
                        IconButton(
                            onClick = { session.undo() },
                            enabled = session.canUndo || session.polygon.isNotEmpty()
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = stringResource(R.string.undo))
                        }
                        IconButton(onClick = { session.redo() }, enabled = session.canRedo) {
                            Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = stringResource(R.string.redo))
                        }
                    }
                    IconButton(onClick = { showParts = true }) {
                        Icon(Icons.Filled.Layers, contentDescription = stringResource(R.string.parts))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                when {
                    controller.loading -> CircularProgressIndicator()
                    session == null -> ImportPrompt(onImport = { picker.launch("image/*") })
                    else -> CutoutCanvas(controller, session, Modifier.fillMaxSize())
                }
            }
            if (session != null) {
                BottomPanel(controller, session, onCut = { showCut = true })
            }
        }
    }

    if (showCut) {
        NameDialog(
            title = stringResource(R.string.cut_save),
            label = stringResource(R.string.part_name),
            initial = "Head",
            confirmText = stringResource(R.string.cut_save),
            cancelText = stringResource(R.string.cancel),
            suggestions = PartSuggestions,
            onConfirm = { name ->
                showCut = false
                controller.cutAndSave(name)
            },
            onDismiss = { showCut = false }
        )
    }

    if (showParts) {
        PartsSheet(controller, onDismiss = { showParts = false })
    }
}

@Composable
private fun ImportPrompt(onImport: () -> Unit) {
    Column(
        Modifier.padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            Icons.Filled.Image,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            stringResource(R.string.import_hint),
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(onClick = onImport, modifier = Modifier.height(56.dp)) {
            Text(stringResource(R.string.import_image))
        }
    }
}

@Composable
private fun BottomPanel(controller: EditorController, session: CutoutSession, onCut: () -> Unit) {
    val tool = controller.tool
    val hint = when (tool) {
        Tool.PAN -> R.string.hint_pan
        Tool.RECT -> R.string.hint_rect
        Tool.POLYGON -> R.string.hint_polygon
        Tool.FREEHAND -> R.string.hint_free
        Tool.ERASER -> R.string.hint_eraser
    }
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                stringResource(hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (tool == Tool.ERASER) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.eraser_size), style = MaterialTheme.typography.labelMedium)
                    Slider(
                        value = controller.eraserRadius,
                        onValueChange = { controller.eraserRadius = it },
                        valueRange = 4f..100f,
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 12.dp)
                    )
                }
            }
            if (tool == Tool.POLYGON && session.polygon.size >= 3) {
                FilledTonalButton(
                    onClick = { session.closePolygon() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text(stringResource(R.string.close_polygon))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ToolButton(Icons.Filled.PanTool, stringResource(R.string.tool_pan), tool == Tool.PAN, { controller.tool = Tool.PAN }, Modifier.weight(1f))
                ToolButton(Icons.Filled.CropSquare, stringResource(R.string.tool_rect), tool == Tool.RECT, { controller.tool = Tool.RECT }, Modifier.weight(1f))
                ToolButton(Icons.Filled.Timeline, stringResource(R.string.tool_polygon), tool == Tool.POLYGON, { controller.tool = Tool.POLYGON }, Modifier.weight(1f))
                ToolButton(Icons.Filled.Gesture, stringResource(R.string.tool_free), tool == Tool.FREEHAND, { controller.tool = Tool.FREEHAND }, Modifier.weight(1f))
                ToolButton(Icons.AutoMirrored.Filled.Backspace, stringResource(R.string.tool_eraser), tool == Tool.ERASER, { controller.tool = Tool.ERASER }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { session.clearSelection() },
                    enabled = session.selection != null || session.polygon.isNotEmpty(),
                    modifier = Modifier.height(52.dp)
                ) {
                    Text(stringResource(R.string.clear_selection), maxLines = 1)
                }
                Button(
                    onClick = onCut,
                    enabled = session.selection != null,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                ) {
                    Icon(Icons.Filled.ContentCut, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text(stringResource(R.string.cut_save), maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun ToolButton(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    val tint = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = tint)
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint, maxLines = 1)
    }
}

@Composable
private fun PartsSheet(controller: EditorController, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val parts = controller.meta?.parts ?: emptyList()
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(stringResource(R.string.parts), style = MaterialTheme.typography.titleLarge)
            if (parts.isEmpty()) {
                Text(stringResource(R.string.no_parts), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 360.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(parts, key = { it.name }) { p ->
                        PartRow(p, controller.partThumbs[p.name], onDelete = { controller.deletePart(p.name) })
                    }
                }
            }
            Button(
                onClick = { controller.exportToGallery() },
                enabled = parts.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Icon(Icons.Filled.SaveAlt, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.export_gallery))
            }
        }
    }
}

@Composable
private fun PartRow(p: PartInfo, thumb: android.graphics.Bitmap?, onDelete: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF12131A)),
            contentAlignment = Alignment.Center
        ) {
            if (thumb != null) {
                Image(
                    bitmap = thumb.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 12.dp)
        ) {
            Text(p.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${p.w}×${p.h}  @ ${p.x}, ${p.y}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete))
        }
    }
}
