@file:OptIn(ExperimentalMaterial3Api::class)

package com.bonestudio.animation.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bonestudio.animation.R
import com.bonestudio.animation.core.ProjectMeta
import com.bonestudio.animation.project.ProjectRepository
import com.bonestudio.animation.storage.BitmapIO
import com.bonestudio.animation.ui.components.ConfirmDialog
import com.bonestudio.animation.ui.components.NameDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
fun HomeScreen(repo: ProjectRepository, refreshKey: Int, onOpen: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var projects by remember { mutableStateOf<List<ProjectMeta>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var showNew by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<ProjectMeta?>(null) }
    var deleteTarget by remember { mutableStateOf<ProjectMeta?>(null) }

    suspend fun reload() {
        projects = withContext(Dispatchers.IO) { repo.list() }
        loaded = true
    }

    LaunchedEffect(refreshKey) { reload() }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(28.dp))
        Text(
            stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            stringResource(R.string.home_subtitle),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { showNew = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.size(8.dp))
            Text(stringResource(R.string.new_project), style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.recent_projects), style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        if (loaded && projects.isEmpty()) {
            Text(
                stringResource(R.string.no_projects),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(projects, key = { it.id }) { p ->
                ProjectCard(
                    repo = repo,
                    p = p,
                    onOpen = { onOpen(p.id) },
                    onRename = { renameTarget = p },
                    onDuplicate = {
                        scope.launch {
                            withContext(Dispatchers.IO) { repo.duplicate(p.id) }
                            reload()
                        }
                    },
                    onDelete = { deleteTarget = p }
                )
            }
        }
    }

    if (showNew) {
        NameDialog(
            title = stringResource(R.string.new_project),
            label = stringResource(R.string.project_name),
            initial = stringResource(R.string.default_project_name),
            confirmText = stringResource(R.string.create),
            cancelText = stringResource(R.string.cancel),
            onConfirm = { name ->
                showNew = false
                scope.launch {
                    val m = withContext(Dispatchers.IO) { repo.create(name) }
                    onOpen(m.id)
                }
            },
            onDismiss = { showNew = false }
        )
    }

    val rt = renameTarget
    if (rt != null) {
        NameDialog(
            title = stringResource(R.string.rename),
            label = stringResource(R.string.project_name),
            initial = rt.name,
            confirmText = stringResource(R.string.rename),
            cancelText = stringResource(R.string.cancel),
            onConfirm = { name ->
                renameTarget = null
                scope.launch {
                    withContext(Dispatchers.IO) { repo.rename(rt.id, name) }
                    reload()
                }
            },
            onDismiss = { renameTarget = null }
        )
    }

    val dt = deleteTarget
    if (dt != null) {
        ConfirmDialog(
            message = stringResource(R.string.delete_confirm),
            confirmText = stringResource(R.string.delete),
            cancelText = stringResource(R.string.cancel),
            onConfirm = {
                deleteTarget = null
                scope.launch {
                    withContext(Dispatchers.IO) { repo.delete(dt.id) }
                    reload()
                }
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun ProjectCard(
    repo: ProjectRepository,
    p: ProjectMeta,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val thumb by produceState<ImageBitmap?>(null, p.id, p.updatedAt) {
        value = withContext(Dispatchers.IO) {
            BitmapIO.load(repo.thumbFile(p.id))?.asImageBitmap()
        }
    }
    var menu by remember { mutableStateOf(false) }
    val dateText = remember(p.updatedAt) {
        DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(p.updatedAt))
    }

    Card(
        onClick = onOpen,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF12131A)),
                contentAlignment = Alignment.Center
            ) {
                val t = thumb
                if (t != null) {
                    Image(
                        bitmap = t,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        Icons.Filled.Image,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Column(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 14.dp)
            ) {
                Text(
                    p.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    stringResource(R.string.project_subtitle, p.parts.size, dateText),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = null)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.rename)) },
                        onClick = {
                            menu = false
                            onRename()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.duplicate)) },
                        onClick = {
                            menu = false
                            onDuplicate()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.delete)) },
                        onClick = {
                            menu = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}
