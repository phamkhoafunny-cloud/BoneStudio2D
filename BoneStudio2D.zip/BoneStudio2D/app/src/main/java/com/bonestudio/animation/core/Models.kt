package com.bonestudio.animation.core

import androidx.annotation.StringRes

/** One cut-out body part. The PNG has the same size as the canvas; x/y/w/h is the opaque bounding box. */
data class PartInfo(
    val name: String,
    val file: String,
    val x: Int,
    val y: Int,
    val w: Int,
    val h: Int
)

data class ProjectMeta(
    val id: String,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val canvasW: Int,
    val canvasH: Int,
    val hasImage: Boolean,
    val parts: List<PartInfo>
)

data class UiMessage(@StringRes val res: Int, val args: List<Any> = emptyList())
