package com.bonestudio.animation.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8AB4FF),
    onPrimary = Color(0xFF00205B),
    primaryContainer = Color(0xFF2B4A8F),
    onPrimaryContainer = Color(0xFFDCE6FF),
    secondary = Color(0xFFB9C6EA),
    background = Color(0xFF12131A),
    onBackground = Color(0xFFE4E5F0),
    surface = Color(0xFF1B1D27),
    onSurface = Color(0xFFE4E5F0),
    surfaceVariant = Color(0xFF272A38),
    onSurfaceVariant = Color(0xFFB5B8C9),
    error = Color(0xFFFF8A80)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun BoneStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, shapes = AppShapes, content = content)
}
