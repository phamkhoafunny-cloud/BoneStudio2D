package com.bonestudio.animation.ui.editor

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.bonestudio.animation.R
import com.bonestudio.animation.core.PartInfo
import com.bonestudio.animation.core.ProjectMeta
import com.bonestudio.animation.core.UiMessage
import com.bonestudio.animation.cutout.CutoutEngine
import com.bonestudio.animation.cutout.CutoutSession
import com.bonestudio.animation.imageprocessing.BitmapDecoder
import com.bonestudio.animation.project.ProjectRepository
import com.bonestudio.animation.storage.BitmapIO
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

enum class Tool { PAN, RECT, POLYGON, FREEHAND, ERASER }

/** Holds all state of one open project and performs the (background) work. */
class EditorController(
    private val appContext: Context,
    private val repo: ProjectRepository,
    val projectId: String
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val metaMutex = Mutex()

    var meta by mutableStateOf<ProjectMeta?>(null)
        private set

    var session by mutableStateOf<CutoutSession?>(null)
        private set

    var loading by mutableStateOf(true)
        private set

    var tool by mutableStateOf(Tool.PAN)

    /** Eraser radius in image pixels. */
    var eraserRadius by mutableFloatStateOf(24f)

    var partThumbs by mutableStateOf<Map<String, Bitmap>>(emptyMap())
        private set

    var message by mutableStateOf<UiMessage?>(null)

    init {
        scope.launch { loadProject() }
    }

    private fun projectDir(): File = repo.dir(projectId)

    private suspend fun loadProject() {
        try {
            val m = repo.load(projectId)
            if (m != null) {
                meta = m
                if (m.hasImage) {
                    val bmp = BitmapIO.load(repo.workingFile(projectId))
                    if (bmp != null) session = CutoutSession(bmp)
                }
                val thumbs = HashMap<String, Bitmap>()
                for (p in m.parts) {
                    val full = BitmapIO.load(File(projectDir(), p.file)) ?: continue
                    val t = BitmapIO.partThumb(full, p.x, p.y, p.w, p.h)
                    if (t != null) thumbs[p.name] = t
                }
                partThumbs = thumbs
            }
        } catch (t: Throwable) {
            message = UiMessage(R.string.import_failed)
        } finally {
            loading = false
        }
    }

    fun importImage(uri: Uri) {
        scope.launch {
            try {
                val bmp = BitmapDecoder.decodeScaled(appContext, uri)
                if (bmp == null) {
                    message = UiMessage(R.string.import_failed)
                    return@launch
                }
                BitmapIO.savePng(bmp, repo.sourceFile(projectId))
                BitmapIO.savePng(bmp, repo.workingFile(projectId))
                BitmapIO.savePng(BitmapIO.thumbnail(bmp, 256), repo.thumbFile(projectId))
                updateMeta { it.copy(canvasW = bmp.width, canvasH = bmp.height, hasImage = true) }
                session = CutoutSession(bmp)
            } catch (t: Throwable) {
                message = UiMessage(R.string.import_failed)
            }
        }
    }

    private suspend fun updateMeta(transform: (ProjectMeta) -> ProjectMeta) {
        metaMutex.withLock {
            val m = meta ?: return
            val nm = transform(m).copy(updatedAt = System.currentTimeMillis())
            repo.save(nm)
            meta = nm
        }
    }

    private suspend fun saveInternal() {
        val s = session
        if (s != null && s.dirty) {
            s.dirty = false
            val bmp = s.working
            BitmapIO.savePng(bmp, repo.workingFile(projectId))
            BitmapIO.savePng(BitmapIO.thumbnail(bmp, 256), repo.thumbFile(projectId))
        }
        updateMeta { it }
    }

    /** Auto-save (called when the app pauses). */
    fun requestSave() {
        scope.launch {
            try {
                saveInternal()
            } catch (t: Throwable) {
                message = UiMessage(R.string.save_failed)
            }
        }
    }

    fun saveThen(done: () -> Unit) {
        scope.launch {
            try {
                saveInternal()
            } catch (t: Throwable) {
                // ignore, still leave the editor
            }
            withContext(Dispatchers.Main) { done() }
        }
    }

    fun cutAndSave(rawName: String) {
        scope.launch {
            val s = session ?: return@launch
            val sel = s.selection
            if (sel == null) {
                message = UiMessage(R.string.no_selection)
                return@launch
            }
            val name = rawName.trim().ifEmpty { "Part" }
            try {
                val result = CutoutEngine.cut(s.working, sel)
                if (result == null) {
                    message = UiMessage(R.string.nothing_to_cut)
                    return@launch
                }
                val safe = BitmapIO.safeFileName(name)
                val relative = "parts/$safe.png"
                BitmapIO.savePng(result.bitmap, File(projectDir(), relative))
                val r = result.bounds
                val info = PartInfo(name, relative, r.left, r.top, r.width(), r.height())
                val thumb = BitmapIO.partThumb(result.bitmap, r.left, r.top, r.width(), r.height())
                updateMeta { m -> m.copy(parts = m.parts.filter { it.name != name } + info) }
                if (thumb != null) partThumbs = partThumbs + (name to thumb)
                saveInternal()
                message = UiMessage(R.string.part_saved, listOf(safe))
            } catch (t: Throwable) {
                message = UiMessage(R.string.save_failed)
            }
        }
    }

    fun deletePart(name: String) {
        scope.launch {
            val m = meta ?: return@launch
            val p = m.parts.firstOrNull { it.name == name } ?: return@launch
            File(projectDir(), p.file).delete()
            updateMeta { cur -> cur.copy(parts = cur.parts.filter { it.name != name }) }
            partThumbs = partThumbs - name
        }
    }

    fun exportToGallery() {
        scope.launch {
            val m = meta ?: return@launch
            var count = 0
            val folder = BitmapIO.safeFileName(m.name)
            for (p in m.parts) {
                val bmp = BitmapIO.load(File(projectDir(), p.file)) ?: continue
                if (BitmapIO.exportToGallery(appContext, folder, BitmapIO.safeFileName(p.name), bmp)) count++
            }
            message = UiMessage(R.string.exported, listOf(count, folder))
        }
    }
}
