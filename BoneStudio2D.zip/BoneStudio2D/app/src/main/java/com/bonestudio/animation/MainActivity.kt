package com.bonestudio.animation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.bonestudio.animation.project.ProjectRepository
import com.bonestudio.animation.ui.editor.EditorController
import com.bonestudio.animation.ui.editor.EditorScreen
import com.bonestudio.animation.ui.home.HomeScreen
import com.bonestudio.animation.ui.theme.BoneStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val appContext = applicationContext
        val repo = ProjectRepository(appContext)
        setContent {
            BoneStudioTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var openId by rememberSaveable { mutableStateOf<String?>(null) }
                    var refreshKey by remember { mutableIntStateOf(0) }
                    val id = openId
                    if (id == null) {
                        HomeScreen(repo, refreshKey) { openId = it }
                    } else {
                        val controller = remember(id) { EditorController(appContext, repo, id) }
                        EditorScreen(controller) {
                            controller.saveThen {
                                openId = null
                                refreshKey++
                            }
                        }
                    }
                }
            }
        }
    }
}
