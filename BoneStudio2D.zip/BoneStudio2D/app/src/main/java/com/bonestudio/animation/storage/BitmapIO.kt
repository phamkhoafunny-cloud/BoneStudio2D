package com.bonestudio.animation.storage

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

object BitmapIO {

    fun savePng(bmp: Bitmap, file: File) {
        file.parentFile?.mkdirs()
        val tmp = File(file.path + ".tmp")
        FileOutputStream(tmp).use { out ->
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.flush()
        }
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }

    fun load(file: File): Bitmap? {
        if (!file.exists()) return null
        val o = BitmapFactory.Options().apply {
            inMutable = true
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return try {
            BitmapFactory.decodeFile(file.absolutePath, o)
        } catch (t: Throwable) {
            null
        }
    }

    fun thumbnail(src: Bitmap, maxSide: Int): Bitmap {
        val longest = max(src.width, src.height)
        if (longest <= maxSide) return src
        val s = maxSide.toFloat() / longest
        return Bitmap.createScaledBitmap(
            src,
            (src.width * s).roundToInt().coerceAtLeast(1),
            (src.height * s).roundToInt().coerceAtLeast(1),
            true
        )
    }

    /** Thumbnail of a part, cropped to its bounding box. */
    fun partThumb(src: Bitmap, x: Int, y: Int, w: Int, h: Int, maxSide: Int = 160): Bitmap? {
        return try {
            val cx = x.coerceIn(0, src.width - 1)
            val cy = y.coerceIn(0, src.height - 1)
            val cw = w.coerceIn(1, src.width - cx)
            val ch = h.coerceIn(1, src.height - cy)
            val crop = Bitmap.createBitmap(src, cx, cy, cw, ch)
            thumbnail(crop, maxSide)
        } catch (t: Throwable) {
            null
        }
    }

    fun safeFileName(name: String): String {
        val cleaned = name.trim()
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .replace(' ', '_')
        return cleaned.ifEmpty { "Part" }
    }

    /** Saves the PNG into Pictures/BoneStudio2D/<project>/ (visible in the Gallery, no permission needed). */
    fun exportToGallery(context: Context, projectName: String, partName: String, bmp: Bitmap): Boolean {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$partName.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BoneStudio2D/$projectName")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            val ok = resolver.openOutputStream(uri)?.use { out ->
                bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            } ?: false
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            ok
        } catch (t: Throwable) {
            false
        }
    }
}
