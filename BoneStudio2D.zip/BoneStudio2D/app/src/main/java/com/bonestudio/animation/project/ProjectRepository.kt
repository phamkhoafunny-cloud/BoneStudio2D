package com.bonestudio.animation.project

import android.content.Context
import com.bonestudio.animation.core.PartInfo
import com.bonestudio.animation.core.ProjectMeta
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Stores every project in filesDir/projects/<id>/ :
 *   project.json (+ .bak for recovery), source.png, working.png, thumb.png, parts/*.png
 */
class ProjectRepository(context: Context) {
    private val root = File(context.filesDir, "projects").apply { mkdirs() }

    fun dir(id: String): File = File(root, id)
    fun workingFile(id: String): File = File(dir(id), "working.png")
    fun sourceFile(id: String): File = File(dir(id), "source.png")
    fun thumbFile(id: String): File = File(dir(id), "thumb.png")

    fun list(): List<ProjectMeta> {
        val dirs = root.listFiles() ?: return emptyList()
        return dirs.filter { it.isDirectory }
            .mapNotNull { load(it.name) }
            .sortedByDescending { it.updatedAt }
    }

    fun create(name: String): ProjectMeta {
        val now = System.currentTimeMillis()
        val meta = ProjectMeta(
            id = UUID.randomUUID().toString(),
            name = name,
            createdAt = now,
            updatedAt = now,
            canvasW = 0,
            canvasH = 0,
            hasImage = false,
            parts = emptyList()
        )
        dir(meta.id).mkdirs()
        save(meta)
        return meta
    }

    fun load(id: String): ProjectMeta? {
        val d = dir(id)
        for (fileName in listOf("project.json", "project.json.bak")) {
            val f = File(d, fileName)
            if (!f.exists()) continue
            try {
                return fromJson(f.readText())
            } catch (e: Exception) {
                // try the backup copy (recovery)
            }
        }
        return null
    }

    @Synchronized
    fun save(meta: ProjectMeta) {
        val d = dir(meta.id)
        d.mkdirs()
        val tmp = File(d, "project.json.tmp")
        tmp.writeText(toJson(meta))
        val f = File(d, "project.json")
        if (f.exists()) {
            try {
                f.copyTo(File(d, "project.json.bak"), overwrite = true)
            } catch (e: Exception) {
                // backup is best effort
            }
        }
        if (!tmp.renameTo(f)) {
            f.delete()
            tmp.renameTo(f)
        }
    }

    fun rename(id: String, newName: String) {
        val m = load(id) ?: return
        save(m.copy(name = newName, updatedAt = System.currentTimeMillis()))
    }

    fun delete(id: String) {
        dir(id).deleteRecursively()
    }

    fun duplicate(id: String): ProjectMeta? {
        val src = dir(id)
        if (!src.exists()) return null
        val newId = UUID.randomUUID().toString()
        src.copyRecursively(dir(newId), overwrite = true)
        val m = load(newId) ?: return null
        val now = System.currentTimeMillis()
        val copy = m.copy(id = newId, name = m.name + " (copy)", createdAt = now, updatedAt = now)
        save(copy)
        return copy
    }

    private fun toJson(m: ProjectMeta): String {
        val o = JSONObject()
        o.put("version", 1)
        o.put("id", m.id)
        o.put("name", m.name)
        o.put("createdAt", m.createdAt)
        o.put("updatedAt", m.updatedAt)
        o.put("canvasW", m.canvasW)
        o.put("canvasH", m.canvasH)
        o.put("hasImage", m.hasImage)
        val arr = JSONArray()
        for (p in m.parts) {
            val po = JSONObject()
            po.put("name", p.name)
            po.put("file", p.file)
            po.put("x", p.x)
            po.put("y", p.y)
            po.put("w", p.w)
            po.put("h", p.h)
            arr.put(po)
        }
        o.put("parts", arr)
        return o.toString(2)
    }

    private fun fromJson(s: String): ProjectMeta {
        val o = JSONObject(s)
        val arr = o.optJSONArray("parts") ?: JSONArray()
        val parts = ArrayList<PartInfo>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            parts.add(
                PartInfo(
                    name = p.getString("name"),
                    file = p.getString("file"),
                    x = p.getInt("x"),
                    y = p.getInt("y"),
                    w = p.getInt("w"),
                    h = p.getInt("h")
                )
            )
        }
        return ProjectMeta(
            id = o.getString("id"),
            name = o.getString("name"),
            createdAt = o.getLong("createdAt"),
            updatedAt = o.getLong("updatedAt"),
            canvasW = o.optInt("canvasW", 0),
            canvasH = o.optInt("canvasH", 0),
            hasImage = o.optBoolean("hasImage", false),
            parts = parts
        )
    }
}
