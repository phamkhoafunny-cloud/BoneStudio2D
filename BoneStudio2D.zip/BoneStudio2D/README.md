# BoneStudio 2D (MVP - Giai doan 1)

Ung dung Android (Kotlin + Jetpack Compose), package `com.bonestudio.animation`, minSdk 31 (Android 12).

## Da co trong ban nay
- Man hinh Home: Du an moi, danh sach du an gan day (thumbnail), doi ten, sao chep, xoa.
- Nhap anh PNG/JPG (tu dong thu nho neu canh dai hon 1600 px de tiet kiem RAM).
- Cutout Editor: Rectangle, Polygon, Freehand, Eraser, Move/Zoom (hai ngon), Undo/Redo.
- Cut & Save Part: luu PNG nen trong suot, cung kich thuoc canvas, giu nguyen vi tri goc.
- Luu/mo project, tu dong luu khi roi app, co ban sao luu project.json.bak.
- Xuat cac bo phan ra Thu vien anh: Pictures/BoneStudio2D/<ten du an>/.
- Giao dien toi, tieng Viet/tieng Anh theo ngon ngu may.

## CHUA co (cac giai doan sau)
Skeleton, Animation, Timeline, IK, Mesh, Sprite Sheet/GIF/JSON/Godot/Java ME export, Tutorial, Light theme.

## Cach 1: Build APK bang GitHub Actions (khong can may tinh manh)
1. Tao repository moi tren GitHub (vi du `BoneStudio2D`).
2. Dua toan bo noi dung thu muc nay len repo (nhanh `main`). Nen dung `git` hoac GitHub Desktop.
   Neu upload bang web va thieu thu muc `.github`, hay chon Add file > Create new file,
   go ten `.github/workflows/android.yml` roi dan noi dung file `android.yml` vao.
3. Vao tab Actions > "Build Debug APK" > Run workflow (hoac push len main la tu chay).
4. Doi workflow xanh (khoang 5-10 phut) > mo lan chay > muc Artifacts > tai `app-debug-apk`.
5. Giai nen file zip duoc `app-debug.apk`, chep vao dien thoai, mo de cai
   (cho phep "Cai ung dung tu nguon khong xac dinh" neu may hoi).

## Cach 2: Build bang Android Studio (may tinh)
1. Cai Android Studio (ban moi), chon Open > thu muc `BoneStudio2D`.
2. Doi Gradle sync xong (se tu tai Gradle 8.7 va SDK 34, can Internet).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK nam o `app/build/outputs/apk/debug/app-debug.apk`.

## Cach 3: Dong lenh (da cai JDK 17, Android SDK, Gradle 8.7)
    gradle assembleDebug

## Luu y trung thuc
Source code nay CHUA duoc bien dich hay chay thu trong moi truong tao ra no (khong co Android SDK).
Neu build bao loi, hay gui log loi de sua.
