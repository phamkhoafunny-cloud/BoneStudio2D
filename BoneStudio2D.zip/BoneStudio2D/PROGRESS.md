# Tien do BoneStudio 2D

## Giai doan 1 (viet xong source, CHUA build/test tren thiet bi)
- [x] Home, Project Manager (tao/mo/doi ten/sao chep/xoa, auto save, backup json)
- [x] Import PNG/JPG
- [x] Cutout: Rectangle, Polygon, Freehand, Eraser, Undo/Redo, Cut & Save Part (PNG alpha)
- [x] Part list co thumbnail, xoa, xuat ra Gallery
- [ ] Magic Wand, Lasso rieng, Brush, Invert, Restore Hidden Parts
- [ ] Rotate/Crop/Resize anh, Sprite Sheet import

## Cau truc
core/ project/ storage/ imageprocessing/ cutout/ ui/{theme,components,home,editor}/

## Tiep theo
Giai doan 2: Part Library, Character Assembly. Giai doan 3: Skeleton Editor. Giai doan 4: Animation/Timeline/Preview.
